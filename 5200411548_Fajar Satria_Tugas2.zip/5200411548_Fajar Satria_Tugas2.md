﻿Kelompok  

` `Anggota : 5200411544  - Rakha Rijal Muharram 

`      `5200411548 – Fajar Satria 

`                  `5200411250 – Tegar Riandi 

`                  `5200411054 – Helga R A W 

**Laporan Tugas2 Prototype** 

1. **ERD, SIAKAD** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.001.jpeg)

2. Database SIA 
- **Tb\_dosen** 

o  ![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.002.png)

- **Tb\_mahasiswa** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.003.png)

- **Tb\_matakuliah** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.004.png)

- **Tb\_administrasi** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.005.png)

- **Tb\_jadwal** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.006.png)

- **Tb\_absen** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.007.png)

3. **Prototype Data Master** 
- **Form Mahasiswa** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.008.jpeg)

- **Form Dosen** 

![](Aspose.Words.1f63c85d-1b87-4993-bea6-bc726028d6a3.009.jpeg)
